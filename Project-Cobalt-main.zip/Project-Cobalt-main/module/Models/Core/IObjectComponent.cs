﻿namespace Project_Cobalt.Models
{
    interface IObjectComponent
    {
    }
}