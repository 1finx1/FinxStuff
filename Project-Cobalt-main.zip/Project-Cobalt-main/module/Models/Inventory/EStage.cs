﻿namespace Project_Cobalt.Models
{
    public enum EStage
    {
        NotSplitting,
        SettingUp,
        Splitting
    }
}