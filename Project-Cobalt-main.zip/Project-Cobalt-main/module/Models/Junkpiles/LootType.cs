﻿namespace Project_Cobalt.Models
{
    public enum LootType : ushort
    {
        None = 0,
        Barrel0 = 46434,
        Barrel1 = 46435,
        Barrel2 = 46439,
        Crate0 = 46436
        
    }
}